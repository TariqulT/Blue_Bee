<?php
include '../lib/Session.php';
Session::checkSession();
?>
<?php include '../config/config.php';?>
<?php include '../lib/Database.php';?>
<?php include '../helpers/Format.php';?>
<?php
    $db     = new Database();
    $format = new Format();
?>
<?php 
if(isset($_GET['msgid'])&&$_GET['msgid']!=NULL){
    $msgid = $_GET['msgid'];
    $sql = "DELETE FROM tbl_contact WHERE id='$msgid'";
    $result = $db->delete($sql);
    if($result){
	    echo "<script>alert('Message deleted successfully');</script>";
	    echo "<script>window.location = 'inbox.php';</script>";
	}
	else{
    	echo "<script>alert('Please try again! ');</script>";
    	echo "<script>window.location = 'inbox.php';</script>";
    }
}
else{
	echo "<script>alert('Please try again! ');</script>";
    echo "<script>window.location = 'inbox.php';</script>";
}
?>