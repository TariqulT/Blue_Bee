﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Update Social Media</h2>
                <div class="block"> 
                <?php 
                $sql = "SELECT * FROM tbl_social WHERE id=1";
                $result = $db->select($sql);
                if($result){
                    $social = $result->fetch_assoc();
                ?>
                <?php
                if($_SERVER['REQUEST_METHOD']=='POST'){
                    $facebook = $format->validation($_POST['facebook']);
                    $twitter = $format->validation($_POST['twitter']);
                    $linkedin = $format->validation($_POST['linkedin']);
                    $google = $format->validation($_POST['google']);
                    $facebook = mysqli_real_escape_string($db->link, $facebook);
                    $twitter = mysqli_real_escape_string($db->link, $twitter);
                    $linkedin = mysqli_real_escape_string($db->link, $linkedin);
                    $google = mysqli_real_escape_string($db->link, $google);

                    if($facebook==''||$twitter==''||$linkedin==''||$google==''){
                        echo "<span class='error'>Every field is required</span>";
                    }
                    else{
                        $sql = "UPDATE tbl_social 
                            SET 
                            facebook = '$facebook',
                            twitter = '$twitter',
                            linkedin = '$linkedin',
                            google = '$google' WHERE id=1";
                        $result = $db->update($sql);
                        if($result){
                            echo "<span class='success'>Data updated successfully</span>";
                        }
                        else{
                            echo "<span class='error'>Error occurs! Try again!!</span>";
                        }
                    }
                }
                ?>              
                 <form action="" method="post" enctype="multipart/form-data">
                    <table class="form">					
                        <tr>
                            <td>
                                <label>Facebook</label>
                            </td>
                            <td>
                                <input type="text" name="facebook" value="<?php echo $social['facebook'];?>" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                                <label>Twitter</label>
                            </td>
                            <td>
                                <input type="text" name="twitter" value="<?php echo $social['twitter'];?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td>
                                <label>LinkedIn</label>
                            </td>
                            <td>
                                <input type="text" name="linkedin" value="<?php echo $social['linkedin'];?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td>
                                <label>Google Plus</label>
                            </td>
                            <td>
                                <input type="text" name="google" value="<?php echo $social['google'];?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php
                    }   
                    ?>
                </div>
            </div>
        </div>
<?php include 'inc/footer.php';?>