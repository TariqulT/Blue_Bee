﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Copyright Text</h2>
                <?php 
                $sql = "SELECT * FROM tbl_footer WHERE id=1";
                $result = $db->select($sql);
                if($result){
                    $row = $result->fetch_assoc();
                ?>
                <?php
                if($_SERVER['REQUEST_METHOD']=='POST'){
                    $copyright = $format->validation($_POST['copyright']);
                    $copyright = mysqli_real_escape_string($db->link, $copyright);
                    
                    if($copyright==''){
                        echo "<span class='error'>Field can not be empty.</span>";
                    }
                    else{
                        $sql = "UPDATE tbl_footer 
                            SET 
                            data = '$copyright' WHERE id=1";
                        $result = $db->update($sql);
                        if($result){
                            echo "<span class='success'>Data updated successfully</span>";
                        }
                        else{
                            echo "<span class='error'>Error occurs! Try again!!</span>";
                        }
                    }
                }
                ?> 
                <div class="block copyblock"> 
                    <form action="" method="post" enctype="multipart/form-data">
                        <table class="form">					
                            <tr>
                                <td>
                                    <input type="text" value="<?php echo $row['data'];?>" name="copyright" class="large" />
                                </td>
                            </tr>
    						
    						 <tr> 
                                <td>
                                    <input type="submit" name="submit" Value="Update" />
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
                <?php
                } 
                ?>
            </div>
        </div>
<?php include 'inc/footer.php';?> 