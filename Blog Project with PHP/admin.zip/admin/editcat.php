<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Category</h2>
               <div class="block copyblock"> 
                <?php
                if($_SERVER['REQUEST_METHOD']=='POST'){
                    $catid = $_GET['catid'];
                    $name = $_POST['name'];
                    $name = mysqli_real_escape_string($db->link, $name);
                    if(empty($name)){
                        echo "<span class='error'>Category name required!</span>";
                    }
                    else{
                        $sql = "UPDATE tbl_category SET name='$name' WHERE id='$catid'";
                        $result = $db->update($sql);
                        if($result){
                            echo "<span class='success'>Category updated successfully</span>";
                        }
                        else{
                            echo "<span class='error'>There was an Error! Please try again!</span>";
                        }
                    }
                }
                ?>
                <?php
                if(isset($_GET['catid'])&&$_GET['catid']!=NULL){
                    $catid = $_GET['catid'];
                    $sql = "SELECT * FROM tbl_category WHERE id='$catid'";
                    $result = $db->select($sql);
                    if(!$result||$result->num_rows<=0){
                        header("Location: catlist.php");
                    }
                    $category = $result->fetch_assoc();
                ?>
                <form action="" method="post">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" name="name" value="<?php echo $category['name'];?>" class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                </form>
                <?php
                }
                else{
                    header("Location: catlist.php");
                } 
                ?>
                
                </div>
            </div>
        </div>
<?php include 'inc/footer.php';?>
