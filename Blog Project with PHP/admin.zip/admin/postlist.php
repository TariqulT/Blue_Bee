﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Post List</h2>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Post Title</th>
							<th>Tags</th>
							<th>Category</th>
							<th>Image</th>
							<th>Author</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$sql = "SELECT * FROM tbl_post ORDER BY id DESC";
						$result = $db->select($sql);
						if($result){
							while($post = $result->fetch_assoc()){
								$catid = $post['cat'];
								$sql = "SELECT * FROM tbl_category WHERE id=$catid";
								$tmp = $db->select($sql);
								$cat = $tmp->fetch_assoc();
						?>
						<tr class="odd gradeX">
							<td><?php echo $post['title'];?></td>
							<td><?php echo $post['tags'];?></td>
							<td><?php echo $cat['name'];?></td>
							<td><img src="../images/<?php echo $post['image'];?>" height='30px' width='40px'></td>
							<td><?php echo $post['author'];?></td>
							<td><?php echo $post['date'];?></td>
							<td><a href="editpost.php?postid=<?php echo $post['id'];?>">Edit</a> || <a onclick="return confirm('Are you sure to Delete!');" href="deletepost.php?postid=<?php echo $post['id'];?>">Delete</a></td>
						</tr>
						<?php
							}
						}
						?>
					</tbody>
				</table>
	
               </div>
            </div>
        </div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>
