 <?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Reply Message</h2>
                <div class="block"> 
                    <?php
                    if(isset($_GET['msgid'])&&$_GET['msgid']!=NULL){
                        $msgid = $_GET['msgid'];
                        $sql = "SELECT * FROM tbl_contact WHERE id='$msgid'";
                        $result = $db->select($sql);
                        if(!$result||$result->num_rows<=0){
                            header("Location: inbox.php");
                        }
                        $message = $result->fetch_assoc();
                    ?> 
                    <?php
                    if($_SERVER['REQUEST_METHOD']=='POST'){
                    	$author = $format->validation($_POST['author']);
                        $sender = $format->validation($_POST['sender']);
                        $subject = $format->validation($_POST['subject']);
                        $message = $format->validation($_POST['message']);

                        $sendmail = mail($sender, $subject, $message, $author);
                        if($sendmail){
                            echo "<span class='success'>Message sent successfully</span>";
                        }
                        else{
                            echo "<span class='error'>Error occurs! Try again!!</span>";
                        }
                    }
                    ?>       
                    <form action="" method="post">
                        <table class="form">
                            <tr>
                                <td>
                                    <label>From</label>
                                </td>
                                <td>
                                    <input type="text" name="author" placeholder='Enter your email here...' class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>To</label>
                                </td>
                                <td>
                                    <input type="text" name="sender" readonly value="<?php echo $message['email'];?>" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Subject</label>
                                </td>
                                <td>
                                    <input type="text" name="subject" placeholder='Enter subject here...' class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td style="vertical-align: top; padding-top: 9px;">
                                    <label>Message</label>
                                </td>
                                <td>
                                    <textarea class="tinymce" name="message"></textarea>
                                </td>
                            </tr>
    						<tr>
                                <td></td>
                                <td>
                                    <input type="submit" name="submit" Value="Send" />
                                </td>
                            </tr>
                        </table>
                    </form>
                    <?php
                    }
                    else{
                        header("Location: inbox.php");
                    } 
                    ?>
                </div>
            </div>
        </div>
<!-- Load TinyMCE -->
<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        setupTinyMCE();
        setDatePicker('date-picker');
        $('input[type="checkbox"]').fancybutton();
        $('input[type="radio"]').fancybutton();
    });
</script>
<?php include 'inc/footer.php';?>
