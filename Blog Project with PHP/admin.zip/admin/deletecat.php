<?php include 'inc/header.php';?>
<?php 
if(isset($_GET['catid'])&&$_GET['catid']!=NULL){
    $catid = $_GET['catid'];
    $sql = "DELETE FROM tbl_category WHERE id='$catid'";
    $result = $db->delete($sql);
    header("Location: catlist.php");
}
else{
	header("Location: catlist.php");
}
?>