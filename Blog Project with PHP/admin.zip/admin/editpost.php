<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Edit Post</h2>
                <div class="block"> 
                    <?php
                    if($_SERVER['REQUEST_METHOD']=='POST'){
                        $postid = $_GET['postid'];
                        $title = mysqli_real_escape_string($db->link, $_POST['title']);
                        $cat = mysqli_real_escape_string($db->link, $_POST['cat']);
                        $body = mysqli_real_escape_string($db->link, $_POST['body']);
                        $tags = mysqli_real_escape_string($db->link, $_POST['tags']);
                        $author = mysqli_real_escape_string($db->link, $_POST['author']);

                        $permited = array('jpg','jpeg','png','gif');
                        $file_name = $_FILES['image']['name'];
                        $file_size = $_FILES['image']['size'];
                        $file_temp = $_FILES['image']['tmp_name'];
                        $div = explode('.', $file_name);
                        $file_ext = strtolower(end($div));
                        $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
                        $uploaded_image = '../images/'.$unique_image;
                        if($title==''||$cat==''||$body==''||$tags==''||$author==''){
                            echo "<span class='error'>Every field is required</span>";
                        }
                        else{
                            if(!empty($file_name)){
                                if($file_size>1048567){
                                    echo "<span class='error'>Image size should be less than 1 MB</span>";
                                }
                                elseif (in_array($file_ext, $permited)==false) {
                                    echo "<span class='error'>You can only upload ".implode(', ', $permited)."</span>";
                                }
                                else{
                                    move_uploaded_file($file_temp, $uploaded_image);
                                    $sql = "UPDATE tbl_post SET cat='$cat',title='$title',body='$body',image='$unique_image',author='$author',tags='$tags' WHERE id='$postid'";
                                    $result = $db->update($sql);
                                    if($result){
                                        echo "<span class='success'>Your post was published</span>";
                                    }
                                    else{
                                        echo "<span class='error'>Error occurs! Try again!!</span>";
                                    }
                                }
                            }
                            else{
                                $sql = "UPDATE tbl_post SET cat='$cat',title='$title',body='$body',author='$author',tags='$tags' WHERE id='$postid'";
                                $result = $db->update($sql);
                                if($result){
                                    echo "<span class='success'>Your post was published</span>";
                                }
                                else{
                                    echo "<span class='error'>Error occurs! Try again!!</span>";
                                }
                            }
                        }
                    }
                    ?> 
                    <?php
                    if(isset($_GET['postid'])&&$_GET['postid']!=NULL){
                        $postid = $_GET['postid'];
                        $sql = "SELECT * FROM tbl_post WHERE id='$postid'";
                        $result = $db->select($sql);
                        if(!$result||$result->num_rows<=0){
                            header("Location: postlist.php");
                        }
                        $post = $result->fetch_assoc();
                    ?>             
                    <form action="" method="post" enctype="multipart/form-data">
                        <table class="form">
                            <tr>
                                <td>
                                    <label>Title</label>
                                </td>
                                <td>
                                    <input type="text" name="title" value="<?php echo $post['title'];?>" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Category</label>
                                </td>
                                <td>
                                    <select id="select" name="cat">
                                        <option>Select Category</option>
                                        <?php
                                        $sql = "SELECT * FROM tbl_category ORDER BY name";
                                        $result = $db->select($sql);
                                        if($result){
                                            while($category = $result->fetch_assoc()){
                                        ?>
                                        <option  <?php if($category['id']==$post['cat']) echo "selected='selected'";?> value=<?php echo $category['id'];?>>
                                            <?php echo $category['name'];?>
                                        </option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Upload Image</label>
                                </td>
                                <td>
                                    <img src="../images/<?php echo $post['image'];?>" height="30px" width="40px"><br>
                                    <input type="file" name="image" />
                                </td>
                            </tr>
                            <tr>
                                <td style="vertical-align: top; padding-top: 9px;">
                                    <label>Content</label>
                                </td>
                                <td>
                                    <textarea class="tinymce" name="body">
                                        <?php echo $post['body'];?>
                                    </textarea>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Tags</label>
                                </td>
                                <td>
                                    <input type="text" name="tags" value="<?php echo $post['tags'];?>" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Author</label>
                                </td>
                                <td>
                                    <input type="text" name="author" value="<?php echo $post['author'];?>" class="medium" />
                                </td>
                            </tr>
    						<tr>
                                <td></td>
                                <td>
                                    <input type="submit" name="submit" Value="Save" />
                                </td>
                            </tr>
                        </table>
                    </form>
                    <?php
                    }
                    else{
                        header("Location: postlist.php");
                    } 
                    ?>
                </div>
            </div>
        </div>
<!-- Load TinyMCE -->
<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        setupTinyMCE();
        setDatePicker('date-picker');
        $('input[type="checkbox"]').fancybutton();
        $('input[type="radio"]').fancybutton();
    });
</script>
<?php include 'inc/footer.php';?>
