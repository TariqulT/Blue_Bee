﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Category List</h2>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Category Name</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$sql = "SELECT * FROM tbl_category ORDER BY name";
						$result = $db->select($sql);
						if($result &&($num_of_row = $result->num_rows)>0){
							for($i=1;$i<=$num_of_row;$i++){
								$category = $result->fetch_assoc();
						?>
						<tr class="odd gradeX">
							<td><?php echo $i;?></td>
							<td><?php echo $category['name'];?></td>
							<td><a href="editcat.php?catid=<?php echo $category['id'];?>">Edit</a> || <a onclick="return confirm('Are you sure to Delete!');" href="deletecat.php?catid=<?php echo $category['id'];?>">Delete</a></td>
						</tr>
						<?php
							}
						}
						else{
							echo "No Category Available";
						}
						?>
					</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>
