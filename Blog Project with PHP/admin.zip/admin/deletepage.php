<?php
include '../lib/Session.php';
Session::checkSession();
?>
<?php include '../config/config.php';?>
<?php include '../lib/Database.php';?>
<?php include '../helpers/Format.php';?>
<?php
    $db     = new Database();
    $format = new Format();
?>
<?php 
if(isset($_GET['id'])&&$_GET['id']!=NULL){
    $id = $_GET['id'];
    $sql = "DELETE FROM tbl_page WHERE id='$id'";
    $result = $db->delete($sql);
    if($result){
	    echo "<script>alert('Post deleted successfully');</script>";
	    echo "<script>window.location = 'index.php';</script>";
	}
	else{
    	echo "<script>alert('Please try again! ');</script>";
    	echo "<script>window.location = 'index.php';</script>";
    }
}
else{
	echo "<script>alert('Please try again! ');</script>";
    echo "<script>window.location = 'index.php';</script>";
}
?>