﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php 
if(isset($_GET['msgid'])){
	$msgid = $_GET['msgid'];
	$sql = "UPDATE tbl_contact
			SET
			status='1'
			WHERE id='$msgid'";
	$result = $db->update($sql);
}
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Inbox</h2>
                <div class="block">        
                    <table class="data display datatable">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Sender</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$sql = "SELECT * FROM tbl_contact WHERE status='0' ORDER BY date";
						$result = $db->select($sql);
						if($result &&($num_of_row = $result->num_rows)>0){
							for($i=1;$i<=$num_of_row;$i++){
								$message = $result->fetch_assoc();
						?>
						<tr class="odd gradeX">
							<td><?php echo $i;?></td>
							<td><?php echo $message['firstname'].' '.$message['lastname'];?></td>
							<td><?php echo $message['email'];?></td>
							<td><?php echo $format->textShorten($message['message'], 30);?></td>
							<td><?php echo $format->formatDate($message['date']);?></td>
							<td>
								<a href="msgview.php?msgid=<?php echo $message['id'];?>">View</a>||
								<a href="msgreply.php?msgid=<?php echo $message['id'];?>">Relpy</a>||
								<a href="?msgid=<?php echo $message['id'];?>">Seen</a>
							</td>
						</tr>
						<?php
							}
						}
						else{
							echo "<tr class='odd gradeX' style='text-align:center;'><td colspan='6'>Empty Inbox</td></tr>";
						}
						?>
					</tbody>
				</table>
               </div>
            </div>

            <div class="box round first grid">
                <h2>Seen Messages</h2>
                <div class="block">        
                    <table class="data display datatable">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Sender</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$sql = "SELECT * FROM tbl_contact WHERE status='1' ORDER BY date";
						$result = $db->select($sql);
						if($result &&($num_of_row = $result->num_rows)>0){
							for($i=1;$i<=$num_of_row;$i++){
								$message = $result->fetch_assoc();
						?>
						<tr class="odd gradeX">
							<td><?php echo $i;?></td>
							<td><?php echo $message['firstname'].' '.$message['lastname'];?></td>
							<td><?php echo $message['email'];?></td>
							<td><?php echo $message['message'];?></td>
							<td><?php echo $message['date'];?></td>
							<td>
								<a href="msgview.php?msgid=<?php echo $message['id'];?>">View</a>||
								<a href="msgdelete.php?msgid=<?php echo $message['id'];?>">Delete</a>
							</td>
						</tr>
						<?php
							}
						}
						else{
							echo "<tr class='odd gradeX' style='text-align:center;'><td colspan='6'>No Seen message</td></tr>";
						}
						?>
					</tbody>
				</table>
               </div>
            </div>
        </div>
<?php include 'inc/footer.php';?>
