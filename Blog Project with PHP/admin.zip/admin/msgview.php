 <?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Message Details</h2>
                <div class="block"> 
                    <?php
                    if(isset($_GET['msgid'])&&$_GET['msgid']!=NULL){
                        $msgid = $_GET['msgid'];
                        $sql = "SELECT * FROM tbl_contact WHERE id='$msgid'";
                        $result = $db->select($sql);
                        if(!$result||$result->num_rows<=0){
                            header("Location: inbox.php");
                        }
                        $message = $result->fetch_assoc();
                    ?> 
                    <?php
                    if($_SERVER['REQUEST_METHOD']=='POST'){
                    	echo "<script>window.location = 'inbox.php';</script>";
                    }
                    ?>       
                    <form action="" method="post">
                        <table class="form">
                            <tr>
                                <td>
                                    <label>Sender Name</label>
                                </td>
                                <td>
                                    <input type="text" readonly value="<?php echo $message['firstname'].' '.$message['lastname'];?>" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Email</label>
                                </td>
                                <td>
                                    <input type="text" readonly value="<?php echo $message['email'];?>" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td style="vertical-align: top; padding-top: 9px;">
                                    <label>Message</label>
                                </td>
                                <td>
                                    <input type="text" readonly value="<?php echo $message['message'];?>" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Date</label>
                                </td>
                                <td>
                                    <input type="text" readonly value="<?php echo $format->formatDate($message['date']);?>" class="medium" />
                                </td>
                            </tr>
    						<tr>
                                <td></td>
                                <td>
                                    <input type="submit" name="submit" Value="OK" />
                                </td>
                            </tr>
                        </table>
                    </form>
                    <?php
                    }
                    else{
                        header("Location: inbox.php");
                    } 
                    ?>
                </div>
            </div>
        </div>
<?php include 'inc/footer.php';?>
