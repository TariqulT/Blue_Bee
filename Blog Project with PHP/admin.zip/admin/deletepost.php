<?php
include '../lib/Session.php';
Session::checkSession();
?>
<?php include '../config/config.php';?>
<?php include '../lib/Database.php';?>
<?php include '../helpers/Format.php';?>
<?php
    $db     = new Database();
    $format = new Format();
?>
<?php 
if(isset($_GET['postid'])&&$_GET['postid']!=NULL){
    $postid = $_GET['postid'];
    $sql = "SELECT * FROM tbl_post WHERE id='$postid'";
    $result = $db->select($sql);
    if(!$result){
    	echo "<script>alert('Please try again! ');</script>";
    	echo "<script>window.location = 'postlist.php';</script>";
    }
    $post = $result->fetch_assoc();
    $img = '../images/'.$post['image'];
    $sql = "DELETE FROM tbl_post WHERE id='$postid'";
    $result = $db->delete($sql);
    if($result){
    	unlink($img);
	    echo "<script>alert('Post deleted successfully');</script>";
	    echo "<script>window.location = 'postlist.php';</script>";
	}
	else{
    	echo "<script>alert('Please try again! ');</script>";
    	echo "<script>window.location = 'postlist.php';</script>";
    }
}
else{
	echo "<script>alert('Please try again! ');</script>";
    echo "<script>window.location = 'postlist.php';</script>";
}
?>